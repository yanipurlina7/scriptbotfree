require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "62895365285151"
global.namaowner = "LIANXYY"

//======== Setting Bot & Link ========//
global.namabot = "Lian-Botz⚡" 
global.namabot2 = "Lian-Botz⚡"
global.foother = "© Copyright Lian-Botz⚡"
global.idsaluran = "-"
global.linkgc = '-'
global.linksaluran = "-"
global.linkyt = '-'
global.linktele = "-"
global.packname = "Created By Lian-Botz⚡"
global.author = "Lian-Botz⚡"

//========== Setting Event ==========//
global.welcome = true
global.autoread = false
global.anticall = false
global.owneroff = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 7000
global.delayjpm = 7000

//========= Setting Url Foto =========//
//Lihat Di Folder Media!

//========== Setting Panell ==========//
global.egg = "15"
global.loc = "1"
global.domain = "https://mylianbotz.inclaim.my.id" ///domain server
global.apikey = "ptla_spTpwfO3gt34P5Lbj8oBDLfOoszIhLSWyCIp8sq1nWl" ///plta
global.capikey = "ptlc_iZiDCqMLpg563zLnkJwfEizzWAQqXx7S3rTqpKhwEkI" ///pltc

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = "62895365285151"
global.gopay = false
global.ovo = false
global.seabank = false
global.pulsa = "6283173295075"
global.qris = fs.readFileSync("./media/qris.jpeg")
                             
//=========== Api Domain ===========//
global.zone1 = "64e56e2b322788eab3aa3d144b581fc2"
global.apitoken1 = "TT-TvTghFH-cdnkI5FI61QLznWfyBfaSEKzzL7f9"
global.tld1 = "rxiws.buzz"

//========== Api Domain 2 ==========//
global.zone2 = "86a8b9f1d51aeb74643ed7d8a6899bc6";
global.apitoken2 = "D74UIajr6_jrh-EjKWqlKGr7q3PNzzbt9kNqYwqO";
global.tld2 = "inclaim.my.id";
//========== Api Domain 3 ==========//
global.zone3 = "5f4a582dd80c518fb2c7a425256fb491";
global.apitoken3 = "iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby";
global.tld3 = "tokopanellku.my.id";
//========== Api Domain 4 ==========//
global.zone4 = "5d1f5612c0a0aea5144bc992a29d047e";
global.apitoken4 = "rcQGbLABlTmYNSn-gPYkLr2ilMxNuEacsRBPooFS";
global.tld4 = "hxlwebsite.my.id";
//========== Api Domain 4 ==========//
global.zone5 = "5d1f5612c0a0aea5144bc992a29d047e";
global.apitoken5 = "rcQGbLABlTmYNSn-gPYkLr2ilMxNuEacsRBPooFS";
global.tld5 = "hxlwebsite.my.id";

//========= Setting Message =========//
global.msg = {
"error": "Error terjasi kesalahan",
"done": "Done Bang ✅", 
"wait": "Bot Sedang Memproses Tunggu Sebentar . . .", 
"group": "*• Group Only* Fitur Ini Hanya Untuk Di Dalam Grup!", 
"private": "*• Private Chat* Fitur Ini Hanya Untuk Didalam Private Chat!", 
"admin": "*• Admin Only* Fitur Ini Hanya Untuk Admin Grup!", 
"adminbot": "*• Bot Admin* Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin", 
"owner": "*• Owner Only* Fitur Ini Hanya Untuk Owner Bot!", 
"developer": "*• Developer Only* Fitur Ini Hanya Untuk Developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})